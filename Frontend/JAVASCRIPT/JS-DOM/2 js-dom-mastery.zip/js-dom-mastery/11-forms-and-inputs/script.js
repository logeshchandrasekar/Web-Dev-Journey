/**
 * TOPIC 11 -- Forms & Inputs
 * ============================================================
 * Reading/writing form values, the difference between the
 * 'input' and 'change' events, and hand-rolled validation
 * (useful when you need custom rules the browser can't express).
 * ============================================================
 */

const form = document.getElementById('signup-form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');

function setError(input, message) {
  const errorEl = document.getElementById(`${input.id}-error`);
  errorEl.textContent = message;
  input.classList.toggle('is-invalid', Boolean(message));
}

function validate() {
  let isValid = true;

  // .value is how you READ (and WRITE) what's currently typed.
  if (username.value.trim().length < 3) {
    setError(username, 'Username needs at least 3 characters.');
    isValid = false;
  } else {
    setError(username, '');
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email.value.trim())) {
    setError(email, "That doesn't look like a valid email.");
    isValid = false;
  } else {
    setError(email, '');
  }

  if (password.value.length < 8) {
    setError(password, 'Password needs at least 8 characters.');
    isValid = false;
  } else {
    setError(password, '');
  }

  return isValid;
}

form.addEventListener('submit', (e) => {
  e.preventDefault(); // stop the real page reload/navigation
  const ok = validate();
  log(ok ? 'Validation passed -- this is where you would send the data to a server.' : 'Validation failed -- see the red messages above.');
});

// Live-validate individual fields as the user types (nice UX touch):
[username, email, password].forEach((input) => {
  input.addEventListener('input', () => {
    if (input.classList.contains('is-invalid')) validate(); // re-check once they've already seen an error
  });
});

/**
 * ------------------------------------------------------------------
 * 'input' vs 'change' -- a classic mix-up.
 *   'input'  -> fires on EVERY value change, immediately (each keystroke).
 *   'change' -> fires only once the value is COMMITTED (usually on blur,
 *               i.e. when the field loses focus, or Enter is pressed).
 * ------------------------------------------------------------------
 */
const compareInput = document.getElementById('compare-input');

compareInput.addEventListener('input', (e) => {
  log('input  event -> live value:', JSON.stringify(e.target.value));
});

compareInput.addEventListener('change', (e) => {
  log('change event -> COMMITTED value (fires on blur/Enter):', JSON.stringify(e.target.value));
});

/**
 * RULE OF THUMB:
 * - Use 'input' for live feedback (character counters, live search).
 * - Use 'change' for anything you only need once the user is "done"
 *   (e.g. a <select> dropdown, a checkbox, or saving on blur).
 */
