/**
 * TOPIC 5 -- Changing Attributes
 * ============================================================
 * Attributes are the key="value" pairs inside a tag, e.g.
 * <img src="..." alt="...">. This file covers reading, writing,
 * and removing them, plus the special dataset API for data-*
 * attributes.
 * ============================================================
 */

const img = document.getElementById('demo-img');
const link = document.getElementById('demo-link');
const div = document.getElementById('demo-div');

// --- getAttribute -----------------------------------------------------
document.getElementById('btn-get').addEventListener('click', () => {
  clearLog();
  log('img src:', img.getAttribute('src'));
  log('link href (raw):', link.getAttribute('href'));
  log('link data-tracking-id:', link.getAttribute('data-tracking-id'));

  // Common attributes ALSO exist as direct properties on the element --
  // usually simpler, but getAttribute always returns the exact string
  // from the HTML, while the property can be normalized. .href, for
  // example, returns a full resolved URL; getAttribute returns it raw.
  log('link.href (property, resolved):', link.href);
});

// --- setAttribute -------------------------------------------------------
document.getElementById('btn-set').addEventListener('click', () => {
  img.setAttribute('src', 'https://placehold.co/120x80/322c3d/6ee7b7?text=Changed');
  img.setAttribute('alt', 'a freshly swapped placeholder image');
  log('Updated img src/alt via setAttribute().');
});

// --- removeAttribute -------------------------------------------------------
document.getElementById('btn-remove').addEventListener('click', () => {
  link.removeAttribute('data-tracking-id');
  log('Removed data-tracking-id. Now:', link.getAttribute('data-tracking-id'));
});

// --- dataset: the clean way to work with data-* attributes -----------------
// Any attribute named "data-something" is automatically exposed on
// element.dataset using camelCase -- no getAttribute needed.
log('div.dataset.userId:', div.dataset.userId); // reads data-user-id
log('div.dataset.role:', div.dataset.role);       // reads data-role

// Writing works the same way, and it's reactive in both directions:
div.dataset.role = 'super-admin';
log('After update, the data-role attribute is now:', div.getAttribute('data-role'));

/**
 * RULE OF THUMB:
 * - Standard attributes (src, href, id, value...) -> use the direct
 *   property when you can (img.src, link.href) -- simpler, and it
 *   handles type conversion for you.
 * - Custom data-* attributes -> always use .dataset, not getAttribute.
 */
