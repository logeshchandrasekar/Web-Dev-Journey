/**
 * TOPIC 9 -- The Event Object
 * ============================================================
 * Every event handler automatically receives an "event object"
 * (conventionally named e or event) packed with details about
 * what just happened, plus tools to control what happens next.
 * ============================================================
 */

const parent = document.getElementById('event-parent');

parent.addEventListener('click', (e) => {
  // event.type: the name of the event that fired.
  log('event.type:', e.type);

  // event.target: the EXACT element that was actually clicked --
  // could be the button, or the div itself, or anything nested.
  log('event.target:', e.target.tagName);

  // event.currentTarget: the element the LISTENER is attached to --
  // here, always the parent div, no matter what you clicked inside it.
  log('event.currentTarget:', e.currentTarget.id);
});

// --- event.preventDefault(): stop the browser's default behavior --------
const link = document.getElementById('demo-link');
link.addEventListener('click', (e) => {
  e.preventDefault(); // without this, the browser would navigate away
  log('Link click intercepted -- preventDefault() stopped the navigation.');
});

const form = document.getElementById('demo-form');
form.addEventListener('submit', (e) => {
  e.preventDefault(); // without this, the page would reload
  log('Form submit intercepted -- preventDefault() stopped the page reload.');
  log('This is where you would validate/send the data with JS instead (see topic 11).');
});

log('Click the button, the link, or submit the form above to see the event object in action.');

/**
 * event.stopPropagation() is demonstrated properly in topic 10,
 * because it only makes sense once you understand bubbling -- but
 * the short version: it stops an event from continuing to travel
 * up to parent elements' listeners.
 */
