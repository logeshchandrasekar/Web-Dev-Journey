/**
 * TOPIC 10 -- Event Bubbling & Capturing
 * ============================================================
 * When you click a deeply nested element, the event doesn't just
 * fire on that element -- it travels through the DOM tree:
 *
 *   CAPTURE phase: document -> outer -> middle -> inner   (top-down)
 *   TARGET phase:  fires on the element you actually clicked
 *   BUBBLE phase:  inner -> middle -> outer -> document    (bottom-up)
 *
 * By default, addEventListener reacts during the BUBBLE phase.
 * ============================================================
 */

const captureToggle = document.getElementById('capture-toggle');
const boxes = ['outer', 'middle', 'inner'].map((id) => document.getElementById(id));

function handleBoxClick(e) {
  const phase = captureToggle.checked ? '[CAPTURE]' : '[BUBBLE] ';
  log(`${phase} listener on "${e.currentTarget.id}" fired.`);
}

function attachListeners(useCapture) {
  boxes.forEach((box) => box.addEventListener('click', handleBoxClick, useCapture));
}
function detachListeners(useCapture) {
  boxes.forEach((box) => box.removeEventListener('click', handleBoxClick, useCapture));
}

attachListeners(false); // start listening during the bubble phase

captureToggle.addEventListener('change', () => {
  // The capture/bubble flag is part of a listener's identity, so it
  // must be removed with the SAME phase flag it was added with.
  detachListeners(!captureToggle.checked);
  attachListeners(captureToggle.checked);
});

log('Click "Inner" and watch the order the 3 boxes log in below.');
log('Toggle the checkbox to compare capture (top-down) vs bubble (bottom-up) order.');

/**
 * ------------------------------------------------------------------
 * EVENT DELEGATION -- the #1 practical use of bubbling.
 * Instead of adding a listener to every single button (including
 * ones that don't exist yet!), add ONE listener to the shared
 * PARENT and use e.target to figure out what was actually clicked.
 * ------------------------------------------------------------------
 */
const todoList = document.getElementById('todo-list-demo');

todoList.addEventListener('click', (e) => {
  // Only react if the click happened on (or inside) a .delete-btn.
  if (e.target.classList.contains('delete-btn')) {
    e.target.closest('li').remove(); // closest() is covered fully in topic 12
    log('Delegated click -> deleted one <li> via the single listener on the <ul>.');
  }
});

document.getElementById('add-item-btn').addEventListener('click', () => {
  const li = document.createElement('li');
  li.innerHTML = `New item <button class="delete-btn">✕</button>`;
  todoList.append(li);
  log('Added a new item -- its delete button ALREADY works, no new listener needed!');
});

/**
 * RULE OF THUMB:
 * - You'll rely on bubbling (the default) 95% of the time.
 * - Use event delegation any time you have a list of similar,
 *   repeating, or dynamically-added elements.
 */
