/**
 * TOPIC 4 -- Changing Content
 * ============================================================
 * Three ways to change what's inside an element. They look similar
 * but behave very differently -- mixing them up is a common bug
 * (and, with innerHTML, a common SECURITY hole).
 * ============================================================
 */

const box = document.getElementById('content-box');

// --- innerHTML ------------------------------------------------------
// Reads/writes the content AS HTML. The browser parses whatever
// string you give it and turns it into real elements.
document.getElementById('btn-innerhtml').addEventListener('click', () => {
  box.innerHTML = 'This is <strong>bold</strong> and <em>italic</em> — the tags were parsed!';
  log('innerHTML set. Notice the <strong>/<em> tags actually rendered.');
});

// --- textContent ------------------------------------------------------
// Reads/writes RAW TEXT only. Any "<tags>" you pass show up as literal
// text, not parsed as HTML. Also grabs hidden text (e.g. inside
// display:none elements) when reading.
document.getElementById('btn-textcontent').addEventListener('click', () => {
  box.textContent = 'This is <strong>bold</strong> — but the tag is just plain text now.';
  log('textContent set. The <strong> tag is now just visible characters.');
});

// --- innerText ------------------------------------------------------
// Similar to textContent, but "layout-aware": it respects CSS (ignores
// display:none text) and triggers a reflow to compute what's actually
// visible -- which makes it slightly slower than textContent.
document.getElementById('btn-innertext').addEventListener('click', () => {
  box.innerText = 'Set via innerText (layout-aware, slightly slower).';
  log('innerText set.');
});

// --- THE DANGER: innerHTML + untrusted input = XSS ----------------
// Never pass user-typed text straight into innerHTML. Here we
// SIMULATE a malicious "username" a user might type into a form.
document.getElementById('btn-danger').addEventListener('click', () => {
  const usernameFromUser = '<img src="x" onerror="alert(\'hacked!\')">';

  // Dangerous -- never do this with real user input:
  //   box.innerHTML = 'Welcome, ' + usernameFromUser;
  // The browser would try to load a broken image, fail, and run the
  // onerror handler -- arbitrary script execution. This pattern is
  // called Cross-Site Scripting (XSS).

  // Safe -- use textContent for anything a user typed:
  box.textContent = 'Welcome, ' + usernameFromUser;
  log('Rendered safely with textContent. The fake "img onerror" stayed inert text.');
  log('If we had used innerHTML here, that tag could have run attacker JS instead.');
});

/**
 * RULE OF THUMB:
 * - Inserting HTML you wrote yourself?      -> innerHTML is fine.
 * - Inserting anything a USER typed?        -> textContent (never innerHTML).
 * - Need the exact rendered text (respects
 *   CSS visibility, slower)?                -> innerText.
 */
