/**
 * TOPIC 14 -- Dynamic Styling & Layout
 * ============================================================
 * Sometimes you need to know WHERE and how BIG an element is --
 * for tooltips, drag-and-drop, infinite scroll, "scroll to top"
 * buttons, sticky headers, etc. This file covers the core
 * measurement APIs.
 * ============================================================
 */

const box = document.getElementById('measure-box');

document.getElementById('measure-btn').addEventListener('click', () => {
  clearLog();

  // --- getBoundingClientRect(): the full picture --------------------
  // Returns the element's size AND position relative to the VIEWPORT
  // (the visible browser window) -- updates live as you scroll.
  const rect = box.getBoundingClientRect();
  log('getBoundingClientRect():');
  log('  top:', Math.round(rect.top), '| left:', Math.round(rect.left));
  log('  width:', Math.round(rect.width), '| height:', Math.round(rect.height));

  // --- offsetWidth / offsetHeight: size including border + padding ----
  // Simpler than getBoundingClientRect when you only need size, not
  // position. Does NOT include margin.
  log('offsetWidth:', box.offsetWidth, '| offsetHeight:', box.offsetHeight);

  // --- offsetTop / offsetLeft: position relative to the nearest
  // "positioned" ancestor (not the viewport -- a common mix-up!)
  log('offsetTop:', box.offsetTop, '| offsetLeft:', box.offsetLeft, '(relative to offsetParent, not the viewport)');
});

// --- Scroll position: how far the PAGE has scrolled -----------------
document.getElementById('scroll-btn').addEventListener('click', () => {
  log('window.scrollY (vertical scroll):', Math.round(window.scrollY));
  log('window.scrollX (horizontal scroll):', Math.round(window.scrollX));

  // You can also ask "is this element currently visible on screen?"
  // by comparing its rect to the viewport size:
  const rect = box.getBoundingClientRect();
  const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
  log('Is #measure-box currently visible in the viewport?', isVisible);
});

/**
 * RULE OF THUMB:
 * - Need position relative to the VIEWPORT (e.g. for a tooltip)?
 *   -> getBoundingClientRect()
 * - Just need width/height?               -> offsetWidth/offsetHeight
 * - Need how far the page has scrolled?   -> window.scrollX/scrollY
 * - For "is this on screen" at scale (many elements), a real app
 *   would reach for IntersectionObserver instead of measuring in a
 *   scroll handler -- worth researching once you're comfortable here.
 */
