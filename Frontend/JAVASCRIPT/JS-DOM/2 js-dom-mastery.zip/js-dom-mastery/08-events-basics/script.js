/**
 * TOPIC 8 -- Events Basics
 * ============================================================
 * Events are how the DOM tells your code "something happened":
 * a click, a keystroke, a page load, etc. addEventListener is
 * how you react to them.
 * ============================================================
 */

// --- The basic pattern: addEventListener(type, handlerFunction) --------
const clickBtn = document.getElementById('click-btn');
clickBtn.addEventListener('click', () => {
  log('Button clicked! Event type: "click"');
});

// --- 'input' fires on EVERY keystroke/change, live -----------------------
document.getElementById('text-input').addEventListener('input', (e) => {
  log('input event -> current value:', JSON.stringify(e.target.value));
});

// --- 'keydown' fires for every physical key press, before the value updates
document.getElementById('keydown-input').addEventListener('keydown', (e) => {
  log('keydown event -> key pressed:', e.key);
});

// --- Listener OPTIONS: { once: true } removes itself after firing --------
document.getElementById('once-btn').addEventListener(
  'click',
  () => log('This ran once -- click the button again, nothing will happen.'),
  { once: true }
);

// --- Removing a listener: needs a NAMED function reference --------------
// You CANNOT remove a listener added with an anonymous arrow function,
// because removeEventListener needs the exact same function reference.
function logToggleClick() {
  log('Toggleable click logger fired!');
}

let listenerEnabled = true;
clickBtn.addEventListener('click', logToggleClick); // a separate, 2nd listener on the same button

document.getElementById('toggle-listener-btn').addEventListener('click', () => {
  if (listenerEnabled) {
    clickBtn.removeEventListener('click', logToggleClick);
    log('Removed the "logToggleClick" listener -- click "Click me" now, that log line stops.');
  } else {
    clickBtn.addEventListener('click', logToggleClick);
    log('Re-added the "logToggleClick" listener.');
  }
  listenerEnabled = !listenerEnabled;
});

/**
 * RULE OF THUMB:
 * - An element can have MANY listeners for the same event -- they
 *   all run (in the order they were added).
 * - To remove a listener later, you MUST use a named/stored function
 *   reference -- inline arrow functions can never be removed.
 * - Common event types: click, input, change, keydown, keyup,
 *   submit, mouseover, mouseout, focus, blur, load.
 */
