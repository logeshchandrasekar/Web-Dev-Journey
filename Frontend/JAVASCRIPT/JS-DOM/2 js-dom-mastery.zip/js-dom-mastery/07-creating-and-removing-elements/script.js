/**
 * TOPIC 7 -- Creating & Removing Elements
 * ============================================================
 * How to build new DOM nodes in JavaScript, and insert or remove
 * them. This is how every dynamic UI (to-do lists, chat messages,
 * search results...) actually gets built.
 * ============================================================
 */

const list = document.getElementById('build-list');

function makeItem(text) {
  const li = document.createElement('li');
  li.textContent = text;
  return li;
}

// --- createElement + appendChild: the classic combo ------------------
// createElement makes a node that exists ONLY in memory so far.
// appendChild attaches it as the LAST child and returns the node.
document.getElementById('btn-create').addEventListener('click', () => {
  const item = document.createElement('li');
  item.textContent = `Item created at ${new Date().toLocaleTimeString()}`;
  list.appendChild(item);
  log('createElement() + appendChild() -> added 1 item to the end.');
});

// --- .append(): the modern, more flexible sibling of appendChild -------
// Differences from appendChild:
//   1) append() can take MULTIPLE arguments at once.
//   2) append() can take plain STRINGS (auto-converted to text nodes).
//   3) append() does not return the appended node (appendChild does).
document.getElementById('btn-append').addEventListener('click', () => {
  list.append(makeItem('Appended item A'), makeItem('Appended item B'), 'a raw text node, no <li> wrapper');
  log('.append() -> added 2 elements AND a raw text string in one call.');
});

// --- .prepend(): same idea as append, but inserts at the FRONT ----------
document.getElementById('btn-prepend').addEventListener('click', () => {
  list.prepend(makeItem('I jumped to the front!'));
  log('.prepend() -> added 1 item to the very top of the list.');
});

// --- insertBefore: precise placement, the older API ----------------------
// Syntax is (newNode, referenceNode) -- "insert newNode before referenceNode".
document.getElementById('btn-insertbefore').addEventListener('click', () => {
  const secondItem = list.children[1];
  if (!secondItem) return log('Need at least 2 items in the list first.');
  list.insertBefore(makeItem('Inserted at position 2'), secondItem);
  log('insertBefore() -> inserted a new item right before the old 2nd item.');
});

// --- removeChild: the older removal API (called ON THE PARENT) -----------
document.getElementById('btn-remove-last').addEventListener('click', () => {
  if (!list.lastElementChild) return log('Nothing left to remove.');
  list.removeChild(list.lastElementChild);
  log('removeChild() -> removed the last <li>, called on the PARENT.');
});

// --- .remove(): the modern removal API (element removes itself) ----------
document.getElementById('btn-remove-modern').addEventListener('click', () => {
  const lastItem = list.lastElementChild;
  if (!lastItem) return log('Nothing left to remove.');
  lastItem.remove(); // no parent reference needed at all
  log('.remove() -> removed the last <li> by calling it ON THE ELEMENT itself.');
});

/**
 * RULE OF THUMB:
 * - Building nodes: createElement (+ set properties) is still standard.
 * - Inserting: prefer append()/prepend() (flexible) over appendChild
 *   unless you specifically need the returned node.
 * - Removing: prefer el.remove() over parent.removeChild(el) -- it
 *   reads better and you don't need a parent reference on hand.
 */
