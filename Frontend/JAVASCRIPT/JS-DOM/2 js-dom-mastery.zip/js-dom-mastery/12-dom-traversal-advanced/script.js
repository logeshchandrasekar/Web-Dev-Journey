/**
 * TOPIC 12 -- DOM Traversal (Advanced)
 * ============================================================
 * Two tools for navigating messy, deeply-nested structures (like
 * a comment thread) without hardcoding assumptions about exactly
 * how many levels deep something is.
 * ============================================================
 */

const commentsRoot = document.getElementById('comments');

// Delegate ONE listener at the root (see topic 10) to handle likes
// on every comment, at any nesting depth, including future replies.
commentsRoot.addEventListener('click', (e) => {
  // --- .matches(selector): "does THIS exact element match a selector?" ---
  if (!e.target.matches('.like-btn')) return; // ignore clicks that aren't on a like button

  // --- .closest(selector): walk UP from this element (including itself)
  // until it finds an ancestor matching the selector, or returns null.
  // Perfect for "find the containing card/row/comment" from a button
  // buried inside it, no matter how deeply nested that button is.
  const commentEl = e.target.closest('.comment');
  const commentId = commentEl.dataset.commentId;

  const nowLiked = e.target.classList.toggle('is-liked');
  e.target.textContent = nowLiked ? '❤ Liked' : '♡ Like';
  log(`Comment #${commentId} -> ${nowLiked ? 'liked' : 'unliked'} (found via closest('.comment')).`);
});

log('Click any "Like" button -- including the nested reply -- to see closest() at work.');
log('e.target.closest(".comment") always finds the RIGHT comment, no matter the nesting depth.');

/**
 * RULE OF THUMB:
 * - matches(selector)  -> "is THIS element a match?" (a yes/no check)
 * - closest(selector)  -> "find the nearest match, starting from THIS
 *   element and walking upward" (a search, not just a check)
 * - Together they make event delegation reliable even in deeply
 *   nested, dynamically changing markup.
 */
