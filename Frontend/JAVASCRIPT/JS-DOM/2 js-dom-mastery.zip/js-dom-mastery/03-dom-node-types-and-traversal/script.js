/**
 * TOPIC 3 -- DOM Node Types & Tree Traversal
 * ============================================================
 * Every element sits inside a tree of relationships: it has a
 * parent, maybe siblings, and maybe children. This file shows
 * the properties you use to move around that tree -- and the
 * key gotcha: NODE-based properties count text/whitespace,
 * ELEMENT-based properties only count actual tags.
 * ============================================================
 */

const middleChild = document.getElementById('middle-child');
const parentItem = document.getElementById('parent-item');
const traverseBtn = document.getElementById('traverse-btn');

traverseBtn.addEventListener('click', () => {
  clearLog();

  // --- Going UP ---------------------------------------------------
  // parentNode / parentElement walk up one level. They're almost
  // always the same thing -- parentElement is only null if the
  // parent happens to not be an element (rare, e.g. the document itself).
  log('middleChild.parentNode:', middleChild.parentNode.tagName);
  log('middleChild.parentElement:', middleChild.parentElement.tagName);

  // --- Going DOWN: NODE-based (includes text nodes!) ---------------
  // Because of the whitespace/newlines in our HTML source, childNodes
  // includes text nodes you didn't "write" on purpose.
  log('parentItem.childNodes.length (nodes, incl. whitespace):', parentItem.childNodes.length);

  // --- Going DOWN: ELEMENT-based (tags only, the one you usually want)
  log('parentItem.children.length (elements only):', parentItem.children.length);

  // --- Going SIDEWAYS: NODE-based siblings -------------------------
  // nextSibling/previousSibling can return a text node (whitespace)
  // instead of the element you expected -- a classic beginner trap.
  log('middleChild.nextSibling.nodeType:', middleChild.nextSibling ? middleChild.nextSibling.nodeType : null, '(3 = text node, often whitespace)');

  // --- Going SIDEWAYS: ELEMENT-based siblings (what you usually want)
  log('middleChild.nextElementSibling:', middleChild.nextElementSibling.textContent.trim());
  log('middleChild.previousElementSibling:', middleChild.previousElementSibling.textContent.trim());

  // --- First/last, node vs element flavors --------------------------
  const list = middleChild.parentElement; // the inner <ul>
  log('list.firstChild.nodeType:', list.firstChild.nodeType, '(often text/whitespace)');
  log('list.firstElementChild:', list.firstElementChild.textContent.trim());
  log('list.lastElementChild:', list.lastElementChild.textContent.trim());
});

/**
 * RULE OF THUMB:
 * Prefer the "Element" versions (children, firstElementChild,
 * nextElementSibling, ...) unless you specifically need to see
 * text nodes or comments too. They save you from whitespace surprises.
 */
