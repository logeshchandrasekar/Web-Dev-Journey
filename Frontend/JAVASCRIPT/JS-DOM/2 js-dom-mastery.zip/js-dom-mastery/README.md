# JS DOM Mastery

Hands-on companion code for the 14-topic "Learning JavaScript DOM from scratch" roadmap. Every topic gets its own runnable HTML page with a `script.js` full of comments that walk through the concept — open the file, click things, read the comments, and watch the on-page **Output** console (everything also prints to your real DevTools console).

## How to use this

1. Unzip the folder.
2. Open any topic's `index.html` directly in a browser (double-click it, or right-click → Open with → your browser). No build step, no server, no `npm install` — just HTML/CSS/vanilla JS.
3. Open DevTools (F12) alongside it — everything logged also prints to the real console.
4. Read `script.js` in each folder top to bottom; the comments ARE the lesson.
5. Use the "← Previous / Next →" links at the bottom of each page to move through the roadmap in order.

## Structure

```
js-dom-mastery/
├── shared/                                reusable styles + the log()/clearLog() helper
├── 01-what-is-the-dom/
├── 02-selecting-elements/
├── 03-dom-node-types-and-traversal/
├── 04-changing-content/
├── 05-changing-attributes/
├── 06-changing-styles-and-classes/
├── 07-creating-and-removing-elements/
├── 08-events-basics/
├── 09-the-event-object/
├── 10-event-bubbling-and-capturing/
├── 11-forms-and-inputs/
├── 12-dom-traversal-advanced/
├── 13-working-with-collections/
└── 14-dynamic-styling-and-layout/
```

Each topic folder has exactly two files:
- `index.html` — a small "playground" with real elements to select, change, and click
- `script.js` — the actual lesson, written as comments + working code

## Roadmap coverage

| # | Topic | Key APIs |
|---|-------|----------|
| 1 | What is the DOM? | `document`, `nodeType`, `nodeName` |
| 2 | Selecting Elements | `getElementById`, `getElementsByClassName`/`TagName`, `querySelector(All)` |
| 3 | DOM Node Types & Tree Traversal | `parentNode`, `childNodes`/`children`, `next`/`previousSibling`, `firstChild`/`lastChild` |
| 4 | Changing Content | `innerHTML`, `textContent`, `innerText` (+ the XSS danger) |
| 5 | Changing Attributes | `getAttribute`/`setAttribute`/`removeAttribute`, `dataset` |
| 6 | Changing Styles & Classes | `element.style`, `classList.add/remove/toggle/contains` |
| 7 | Creating & Removing Elements | `createElement`, `appendChild`/`append`/`prepend`/`insertBefore`, `removeChild`/`remove` |
| 8 | Events Basics | `addEventListener`, event types, `removeEventListener` |
| 9 | The Event Object | `event.target`, `event.type`, `preventDefault`, `stopPropagation` |
| 10 | Event Bubbling & Capturing | capture vs bubble phase, event delegation |
| 11 | Forms & Inputs | form values, `change` vs `input`, custom validation |
| 12 | DOM Traversal (Advanced) | `closest()`, `matches()` |
| 13 | Working with Collections | `NodeList` vs `HTMLCollection`, `Array.from` |
| 14 | Dynamic Styling & Layout | `getBoundingClientRect`, `offsetWidth`/`Height`, `scrollX`/`Y` |

This maps 1:1 to the roadmap, so each folder here would also work well as a module in ProgTrack if you want to track your progress through it there.

Happy hacking!
