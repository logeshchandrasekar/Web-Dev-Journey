/**
 * TOPIC 1 -- What is the DOM?
 * ============================================================
 * DOM = "Document Object Model".
 *
 * When the browser loads an HTML file, it doesn't keep the HTML
 * as plain text. It PARSES it into a tree of JavaScript objects --
 * one object per tag, comment, and even chunk of text. That tree
 * of objects is the DOM, and it's what JavaScript actually talks to.
 *
 *   <article>                document
 *     <h3>...</h3>              |__ html
 *     <p>...</p>                     |__ head
 *     <ul>                          |__ body
 *       <li>...</li>                     |__ article
 *       <li>...</li>                          |__ h3
 *     </ul>                                   |__ p
 *   </article>                                |__ ul
 *                                                  |__ li
 *                                                  |__ li
 *
 * Every box in that tree is called a "node". This file proves the
 * tree is real by walking it and logging what we find.
 * ============================================================
 */

// `document` is the entry point to the whole tree -- it represents
// the entire HTML page and is provided automatically by the browser.
log('typeof document:', typeof document);

// document.documentElement is the <html> tag itself.
log('Root element:', document.documentElement.tagName);

// document.head and document.body are shortcuts to those two tags.
log('Head tag:', document.head.tagName, '| Body tag:', document.body.tagName);

const inspectBtn = document.getElementById('inspect-btn');
const article = document.getElementById('demo-article');

inspectBtn.addEventListener('click', () => {
  clearLog();
  log('--- Walking the <article> node ---');

  // .nodeType tells us WHAT KIND of node something is.
  // 1 = Element, 3 = Text, 8 = Comment, 9 = Document.
  log('article.nodeType:', article.nodeType, '(1 = Element node)');
  log('article.nodeName:', article.nodeName);

  // A "node" is the general concept (element, text, comment...).
  // An "element" is specifically a TAG. All elements are nodes, but
  // not all nodes are elements (text counts as a node too!).
  log('article instanceof Element?', article instanceof Element);
  log('article instanceof Node?', article instanceof Node);

  // The browser converts EVERYTHING in the HTML into a node,
  // including the whitespace/line breaks between tags -- that's
  // why childNodes (topic 3) often looks bigger than you'd expect.
  log('Direct child NODES of <article> (includes text/whitespace):', article.childNodes.length);
  log('Direct child ELEMENTS of <article> (tags only):', article.children.length);
});

log('Page loaded. Click "Inspect this tree" to explore the DOM above.');
