/**
 * TOPIC 13 -- Working with Collections
 * ============================================================
 * querySelectorAll and getElementsByClassName both return
 * "collections" of elements -- but they behave very differently
 * when the DOM changes afterward, and neither is a true Array.
 * ============================================================
 */

const list = document.getElementById('collection-list');

document.getElementById('run-comparison').addEventListener('click', () => {
  clearLog();

  // A LIVE HTMLCollection -- this variable auto-updates if the DOM changes.
  const liveItems = document.getElementsByClassName('item');

  // A STATIC NodeList -- this is a snapshot, frozen at the moment it was captured.
  const staticItems = document.querySelectorAll('.item');

  log('Before adding a new item:');
  log('  live HTMLCollection length:', liveItems.length);
  log('  static NodeList length:', staticItems.length);

  const newItem = document.createElement('li');
  newItem.className = 'item';
  newItem.textContent = 'Date (added dynamically)';
  list.appendChild(newItem);

  log('After adding a new item to the DOM:');
  log('  live HTMLCollection length:', liveItems.length, '<- updated automatically!');
  log('  static NodeList length:', staticItems.length, '<- unchanged, a frozen snapshot!');
});

document.getElementById('add-collection-item').addEventListener('click', () => {
  const item = document.createElement('li');
  item.className = 'item';
  item.textContent = `Item ${list.children.length + 1}`;
  list.appendChild(item);
  log('Added an item directly. Click "Compare" above to see how each collection type reacts.');
});

// --- Neither is a real Array -- you'll often want to convert one --------
const items = document.querySelectorAll('.item');

// Option 1: Array.from()
const asArray1 = Array.from(items);
// Option 2: spread syntax -- const asArray2 = [...items];

log('Array.from(NodeList) gives real array methods, e.g. .map():');
log(asArray1.map((el) => el.textContent).join(', '));

// NodeLists (from querySelectorAll) DO support .forEach() directly --
// but HTMLCollections (from getElementsByClassName) do NOT, so
// converting first is the safer habit either way.
items.forEach((el) => {
  el.title = 'Hovered via a NodeList.forEach() loop'; // sets a tooltip
});

/**
 * RULE OF THUMB:
 * - getElementsBy___()   -> live HTMLCollection (auto-updates, array-ish but NOT an array)
 * - querySelector(All)   -> static NodeList (frozen snapshot; forEach works, map/filter don't)
 * - Need map/filter/reduce, or reliable behavior either way?
 *   -> Array.from(collection) or [...collection] first.
 */
