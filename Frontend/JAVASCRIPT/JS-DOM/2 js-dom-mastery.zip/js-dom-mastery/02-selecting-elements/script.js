/**
 * TOPIC 2 -- Selecting Elements
 * ============================================================
 * Before you can change anything on a page, you have to find it
 * first. The DOM gives you several ways to select elements --
 * this file compares all of them side by side.
 * ============================================================
 */

// --- getElementById -----------------------------------------
// Fastest selector. Returns ONE element (ids must be unique) or null.
const box = document.getElementById('unique-box');
log('getElementById ->', box.textContent.trim());

// --- getElementsByClassName -----------------------------------
// Returns a LIVE HTMLCollection of every element with that class.
// "Live" means it auto-updates if the DOM changes later (see topic 13).
const highlighted = document.getElementsByClassName('highlight');
log('getElementsByClassName -> found', highlighted.length, 'elements');

// --- getElementsByTagName ---------------------------------------
// Same idea, but matches by tag name instead of class.
const paragraphs = document.getElementsByTagName('p');
log('getElementsByTagName("p") -> found', paragraphs.length, 'paragraphs');

// --- querySelector ------------------------------------------------
// Accepts ANY CSS selector and returns the FIRST match, or null.
// This is the modern, most flexible way to select a single element.
const firstHighlight = document.querySelector('.highlight');
log('querySelector(".highlight") ->', firstHighlight.textContent.trim());

// You can combine selectors just like in CSS:
const primaryBtn = document.querySelector('button[data-role="primary"]');
log('querySelector(\'button[data-role="primary"]\') ->', primaryBtn.textContent.trim());

// --- querySelectorAll --------------------------------------------
// Same as querySelector but returns a STATIC NodeList of ALL matches.
// "Static" means it does NOT update automatically (again, see topic 13).
const allButtons = document.querySelectorAll('.action-btn');
log('querySelectorAll(".action-btn") -> found', allButtons.length, 'buttons');

// NodeLists from querySelectorAll support forEach directly:
allButtons.forEach((btn) => log('  button found:', btn.dataset.role));

/**
 * RULE OF THUMB:
 * - Need ONE element?         -> querySelector (or getElementById if it has an id)
 * - Need MULTIPLE elements?   -> querySelectorAll
 * - getElementsBy___ still works, but querySelector(All) is more
 *   flexible because it understands full CSS syntax.
 */
