/**
 * TOPIC 6 -- Changing Styles & Classes
 * ============================================================
 * Two ways to change how an element looks: (1) touch its inline
 * style directly, or (2) toggle CSS classes on/off and let a
 * stylesheet do the work. Option 2 is almost always the better
 * approach.
 * ============================================================
 */

const styleBox = document.getElementById('style-box');

// --- element.style: direct inline styles -----------------------------
// Good for one-off, calculated values (e.g. positioning from JS math).
// Bad for anything reusable -- it mixes design decisions into JS and
// is awkward to override with normal CSS rules later.
document.getElementById('btn-inline').addEventListener('click', () => {
  styleBox.style.background = '#0ea5e9';
  styleBox.style.color = '#fff';
  styleBox.style.transform = 'scale(1.03)';
  log('Set 3 inline style properties directly on the element.');
});

// --- classList.add: the preferred approach ----------------------------
// Instead of hardcoding colors in JS, we flip a class on/off and let
// the CSS rules (written in this page's <style> block) decide the look.
document.getElementById('btn-add').addEventListener('click', () => {
  styleBox.classList.add('is-active');
  log('Added class "is-active". Classes now:', styleBox.className);
});

document.getElementById('btn-remove').addEventListener('click', () => {
  styleBox.classList.remove('is-active');
  log('Removed class "is-active". Classes now:', styleBox.className || '(none)');
});

// --- classList.toggle: add if missing, remove if present -----------------
// Perfect for "expanded/collapsed" or "active/inactive" style states.
document.getElementById('btn-toggle').addEventListener('click', () => {
  const isNowActive = styleBox.classList.toggle('is-danger');
  log('Toggled "is-danger". Is it on now?', isNowActive);
});

// --- classList.contains: check state without guessing --------------------
document.getElementById('btn-contains').addEventListener('click', () => {
  log('Does the box currently have "is-active"?', styleBox.classList.contains('is-active'));
  log('Does the box currently have "is-danger"?', styleBox.classList.contains('is-danger'));
});

/**
 * RULE OF THUMB:
 * - Prefer classList (add/remove/toggle) + real CSS rules.
 * - Reach for element.style only for values that are truly computed
 *   at runtime (e.g. `el.style.left = x + 'px'` from a drag gesture).
 */
