/**
 * shared/log.js
 * --------------------------------------------------------------
 * A tiny helper loaded by every lesson in this course. It is NOT
 * part of the lesson itself -- think of it as the course's "print
 * to screen" utility, so results are visible without needing
 * DevTools open (though you should still open DevTools -- every
 * message below is also sent to console.log).
 * --------------------------------------------------------------
 */

// Prints a line to BOTH the real console and the on-page "Output" panel.
function log(...args) {
  console.log(...args);

  const panel = document.getElementById('output');
  if (!panel) return;

  const line = document.createElement('div');
  line.className = 'console-line';
  line.textContent = args
    .map((a) => (typeof a === 'object' && a !== null ? JSON.stringify(a) : String(a)))
    .join(' ');
  panel.appendChild(line);
  panel.scrollTop = panel.scrollHeight;
}

// Wipes the on-page Output panel (does not affect the real console).
function clearLog() {
  const panel = document.getElementById('output');
  if (panel) panel.innerHTML = '';
}

// Wires up the "Clear" button that appears on every lesson page.
document.addEventListener('DOMContentLoaded', () => {
  const clearBtn = document.getElementById('clear-btn');
  if (clearBtn) clearBtn.addEventListener('click', clearLog);
});
