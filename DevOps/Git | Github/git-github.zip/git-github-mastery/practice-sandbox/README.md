# Practice Sandbox

A disposable mini "project" to run every exercise in this course against, so you're practicing on real files and real diffs instead of imaginary ones.

## Setup

```bash
cd practice-sandbox
git init
```

That's it -- the `starter-files/` folder already has a few small files (`index.html`, `style.css`, `app.js`) that make up a tiny placeholder homepage. They're intentionally simple: enough to have realistic content to add, edit, break, and merge, without being a real project you need to worry about "getting right."

## How it's used

Every chapter in `git/` and `github/` has a "Try it yourself" section that assumes you're working inside this folder, in this state. Follow them in order -- later chapters build on commits/branches created in earlier ones.

## If you make a mess

That's genuinely fine -- this folder exists specifically so mistakes here are free. If it gets too tangled to follow along, the fastest reset is to delete the local repo (not the files) and start the Git history over:

```bash
rm -rf .git
git init
git add -A
git commit -m "Reset practice sandbox"
```
