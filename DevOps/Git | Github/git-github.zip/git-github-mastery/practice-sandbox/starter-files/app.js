// Nothing fancy here on purpose -- this file exists so exercises
// have somewhere realistic to add lines, create conflicts, and
// practice diffing/committing/branching against.

console.log('Practice sandbox loaded.');
