# Git Cheatsheet

Dense reference for lookup speed. For explanations and context, see the `git/` chapters this mirrors.

## Setup
```bash
git config --global user.name "Name"
git config --global user.email "you@example.com"
git config --global init.defaultBranch main
git init
git clone <url>
```

## Staging & committing
```bash
git status
git add <file>              # stage one file
git add .                    # stage everything below current dir
git add -p                   # stage interactively, chunk by chunk
git diff                     # working dir vs staging (unstaged)
git diff --staged            # staging vs last commit
git commit -m "message"
git commit -am "message"     # add tracked files + commit (skips new untracked files)
git commit --amend -m "msg"  # rewrite the last commit's message
```

## History
```bash
git log
git log --oneline --graph --all --decorate
git log -p                   # with full diffs
git log --stat               # with file summaries
git show <hash>
git diff <hash1> <hash2>
git blame <file>
```

## Undoing
```bash
git restore <file>              # discard working-dir changes
git restore --staged <file>     # unstage (keep edits)
git reset --soft HEAD~1         # undo commit, keep staged
git reset HEAD~1                # undo commit, keep in working dir (unstaged)
git reset --hard HEAD~1         # DESTRUCTIVE: undo commit + discard changes
git revert <hash>                # safe undo via a new commit (for shared history)
```

## Branching
```bash
git branch                    # list
git branch <name>              # create
git switch <name>              # switch
git switch -c <name>            # create + switch
git branch -d <name>            # delete (safe)
git branch -D <name>            # delete (force)
git branch -m <old> <new>        # rename
```

## Merging & rebasing
```bash
git merge <branch>
git merge --abort
git mergetool
git rebase <branch>
git rebase -i HEAD~n           # interactive: pick/reword/squash/fixup/drop
git rebase --continue / --skip / --abort
```

## Remotes
```bash
git remote -v
git remote add origin <url>
git fetch origin                 # download only, don't merge
git pull origin main              # fetch + merge
git pull --rebase origin main     # fetch + rebase
git push origin main
git push -u origin main           # set upstream, once
git push --force-with-lease       # safer force-push after rewriting pushed history
```

## Stashing & cleaning
```bash
git stash push -m "message"
git stash -u                     # include untracked files
git stash list
git stash pop                     # restore + remove
git stash apply                   # restore, keep in list
git clean -n                       # dry run
git clean -fd                       # delete untracked files + dirs
```

## Tags
```bash
git tag -a v1.0.0 -m "message"    # annotated (preferred)
git tag v1.0.0                     # lightweight
git push origin v1.0.0
git push origin --tags
git tag -d v1.0.0                   # delete locally
git push origin --delete v1.0.0     # delete on remote
```

## Advanced
```bash
git cherry-pick <hash>
git reflog
git bisect start / good / bad / reset
git submodule add <url>
git worktree add ../path <branch>
```

## Config & aliases
```bash
git config --global alias.co switch
git config --global alias.lg "log --oneline --graph --all --decorate"
git config --list --show-origin
```

## Undo decision table

| Situation | Command |
|---|---|
| Discard uncommitted edits | `git restore <file>` |
| Unstage but keep edits | `git restore --staged <file>` |
| Fix the last commit (unpushed) | `git commit --amend` |
| Undo a commit (unpushed) | `git reset` |
| Undo a commit (already pushed/shared) | `git revert` |
| Find a "lost" commit | `git reflog` |
