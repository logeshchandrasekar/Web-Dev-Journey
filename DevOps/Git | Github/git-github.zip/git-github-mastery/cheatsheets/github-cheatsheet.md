# GitHub Cheatsheet

Dense reference for lookup speed. For explanations and context, see the `github/` chapters this mirrors.

## SSH setup (once, per machine)
```bash
ssh-keygen -t ed25519 -C "you@example.com"
cat ~/.ssh/id_ed25519.pub          # paste into GitHub -> Settings -> SSH and GPG keys
ssh -T git@github.com               # test
```

## Connecting a repo
```bash
git remote add origin git@github.com:<user>/<repo>.git    # existing local repo
git clone git@github.com:<user>/<repo>.git                  # start from GitHub's copy
```

## The GitHub Flow
```bash
git switch -c feature/my-change
# ...commit...
git push -u origin feature/my-change
# open a Pull Request on github.com, or: gh pr create
# review -> merge -> delete branch
```

## Linking issues from commits/PRs
```
Closes #12
Fixes #12
Resolves #12
```

## Merge strategies (pick in the PR merge button)

| Strategy | History result |
|---|---|
| Merge commit | Full history + a merge commit, same as local `git merge` |
| Squash and merge | All branch commits become ONE commit on the base branch |
| Rebase and merge | Branch commits replayed individually, no merge commit |

## GitHub Actions skeleton
```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install -r requirements.txt
      - run: pytest
```

## GitHub Pages sources
- **Deploy from a branch** -- plain HTML/CSS/JS, no build step
- **GitHub Actions** -- anything with a build step (React, Jekyll, Hugo, Astro...)
- URLs: `https://<user>.github.io` (user page, repo must be named exactly `<user>.github.io`) or `https://<user>.github.io/<repo>` (project page)

## Security checklist
- [ ] `.env`, `*.pem`, and similar are in `.gitignore` **before** they ever contain real values
- [ ] Real secrets live in **Settings -> Secrets and variables -> Actions**, referenced as `${{ secrets.NAME }}`
- [ ] Branch protection on `main`: require PR + require status checks
- [ ] `LICENSE` file present
- [ ] Dependabot alerts enabled (**Settings -> Code security and analysis**)

## `gh` CLI quick reference
```bash
gh auth login
gh repo create <name> --public --clone
gh repo clone <user>/<repo>
gh pr create --title "..." --body "Closes #N"
gh pr list
gh pr checkout <number>
gh issue create --title "..."
gh issue list --label bug
gh workflow list
gh run list
```
