# Git 01 — Introduction & Setup

> What problem Git actually solves, installing it, telling it who you are, and creating your first repository.

## Why version control?

Before touching a single command, it's worth being clear on the problem. Without version control, "keeping track of changes" usually looks like:

```
report_final.docx
report_final_v2.docx
report_final_v2_ACTUAL.docx
report_final_v2_ACTUAL_fixed.docx
```

That approach has no way to see *what* changed between versions, no way to combine two people's edits, and no way to safely experiment and throw the experiment away. Version control systems solve exactly this: they record snapshots of a project over time, let you compare any two snapshots, restore an old one, and let multiple people work on the same files without overwriting each other.

**Git** is a *distributed* version control system, which matters more than it sounds: every clone of a repository has the *entire* history, not just the latest snapshot. There's no single "master server" required for Git itself to work — GitHub is a popular place to host a copy, but it's a hosting choice, not a requirement (more on that distinction throughout this course).

## Installing Git

Check whether you already have it:

```bash
git --version
```

If that fails:
- **Windows** — download the installer from [git-scm.com](https://git-scm.com), or `winget install --id Git.Git -e`
- **macOS** — `brew install git`, or install Xcode Command Line Tools (`xcode-select --install`)
- **Linux (Debian/Ubuntu)** — `sudo apt update && sudo apt install git`
- **Linux (Fedora)** — `sudo dnf install git`

## Telling Git who you are

Git stamps every commit with an author name and email. Set these once, globally, and every repo on your machine will use them:

```bash
git config --global user.name "Loki"
git config --global user.email "you@example.com"
```

A couple of other one-time settings worth doing now:

```bash
# Make "main" the default name for a repo's first branch (modern convention)
git config --global init.defaultBranch main

# Pick an editor for commit messages, merge messages, etc. (nano is beginner-friendly)
git config --global core.editor "nano"
```

See everything you've configured, and where each setting came from:

```bash
git config --list --show-origin
```

(Chapter 12 covers the full configuration system — global vs per-repo settings, and aliases.)

## Creating your first repository

Inside any folder you want Git to start tracking:

```bash
git init
```

This creates a hidden `.git/` folder. That folder *is* the repository — it holds the entire history, all branches, and all of Git's internal bookkeeping. Delete `.git/` and the folder goes back to being an ordinary, untracked directory (the actual files are untouched, but all history is gone).

## The three areas

This is the single most important mental model in Git. Every file in your project lives in one (or more) of three places:

```
+---------------------+   git add    +--------------------+   git commit   +--------------------+
|  Working Directory  | -----------> |   Staging Area      | ------------>  |   Repository        |
|  (your actual files)|              |  (the "index")      |                |  (.git history)      |
+---------------------+              +--------------------+                +--------------------+
```

- **Working directory** — the actual files on disk, as you're editing them.
- **Staging area** (a.k.a. "the index") — a holding area where you build up *exactly* the changes you want in your next commit. This is what makes Git different from most other tools: you don't commit "everything that changed," you commit "what you've staged."
- **Repository** — the permanent, committed history stored in `.git/`.

## Checking where you stand: `git status`

This is the command you will run more than any other. It tells you, in plain English, what's changed and what state each change is in:

```bash
git status
```

Typical output on a brand new file:

```
On branch main
No commits yet
Untracked files:
  (use "git add <file>..." to include in what will be committed)
	notes.txt
```

## Try it yourself

In `practice-sandbox/`:

```bash
cd practice-sandbox
git init
git config user.name "Loki"        # local override, just for this repo (optional if already global)
git status
```

Confirm you see `starter-files/` listed as untracked. Don't add or commit anything yet — that's chapter 2.

## Recap

- Version control = snapshots over time + safe collaboration + safe experimentation.
- `git --version` to check install, `git config --global user.name/user.email` to identify yourself.
- `git init` turns any folder into a repository by creating `.git/`.
- Every file sits in the working directory, the staging area, and/or the repository — internalize this diagram, it explains almost every command you'll learn from here on.
- `git status` tells you exactly where things stand at any time.

---
[← Course home](../../README.md) | [Next → Staging & Committing](../02-staging-and-committing/README.md)
