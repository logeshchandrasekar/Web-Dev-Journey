# Git & GitHub Mastery

A complete, hands-on curriculum for learning Git and GitHub from first principles to a working developer's level of fluency. 19 chapters split into two tracks — **Git** (the tool, run locally) and **GitHub** (the platform, built on top of it) — plus a practice sandbox and two quick-reference cheatsheets.

## Why two tracks?

**Git** is a version control tool that runs entirely on your machine. You could use it for your whole career without ever touching GitHub. **GitHub** is a website/service that *hosts* Git repositories and adds collaboration features (pull requests, issues, Actions, Pages...) on top. Keeping them separate in this course mirrors reality: most Git problems are Git problems, and most collaboration-workflow questions are GitHub questions.

## How to use this course

1. **Read in order.** Each chapter builds on the last — `git/01` through `git/12`, then `github/01` through `github/07`. Every chapter ends with a "← Previous / Next →" link.
2. **Actually type the commands.** Reading about `git rebase` and running it are very different experiences. Use `practice-sandbox/` as a disposable playground — it has a few starter files so you have something real to commit, branch, and merge.
3. **Do the exercise at the end of every chapter** before moving on. They're short by design.
4. **Keep the cheatsheets open** in a second tab once you've finished a track — they're built for lookup speed, not teaching.
5. **The best exercise of all:** once you're through the Git track, turn this entire folder into a real repo and push it to GitHub (`git init`, commit, create a repo on GitHub, push). You'll be practicing chapter `git/08` and everything in the `github/` track on the actual material you just learned from.

## Structure

```
git-github-mastery/
├── git/                                the tool: 12 chapters, run entirely on your machine
│   ├── 01-introduction-and-setup/
│   ├── 02-staging-and-committing/
│   ├── 03-viewing-history/
│   ├── 04-undoing-changes/
│   ├── 05-branching/
│   ├── 06-merging-and-conflicts/
│   ├── 07-rebasing/
│   ├── 08-working-with-remotes/
│   ├── 09-stashing-and-cleaning/
│   ├── 10-tags-and-releases/
│   ├── 11-advanced-git/
│   └── 12-config-aliases-and-gitignore/
├── github/                             the platform: 7 chapters, built on top of Git
│   ├── 01-getting-started-with-github/
│   ├── 02-github-flow-and-pull-requests/
│   ├── 03-issues-projects-and-collaboration/
│   ├── 04-github-actions-ci-cd/
│   ├── 05-github-pages/
│   ├── 06-security-and-best-practices/
│   └── 07-github-cli-and-beyond/
├── practice-sandbox/                   a disposable mini "project" to run every exercise against
│   └── starter-files/
└── cheatsheets/                        dense, lookup-speed references (read these AFTER the chapters)
    ├── git-cheatsheet.md
    └── github-cheatsheet.md
```

Every chapter folder has one `README.md` with: the concept, the exact commands, a worked example, common mistakes, a short hands-on exercise, and a recap.

## Full roadmap

### Git track

| # | Chapter | Covers |
|---|---------|--------|
| 1 | Introduction & Setup | What version control solves, installing Git, `git config`, `git init`, the three areas |
| 2 | Staging & Committing | `git add`, `git status`, `git commit`, `git diff`, `.gitignore`, writing good commit messages |
| 3 | Viewing History | `git log` (and its useful flags), `git show`, `git diff` between commits, `git blame` |
| 4 | Undoing Changes | `git restore`, `git reset` (soft/mixed/hard), `git revert`, `git commit --amend` |
| 5 | Branching | `git branch`, `git switch`/`checkout -b`, branches as pointers, `git log --graph` |
| 6 | Merging & Conflicts | Fast-forward vs 3-way merges, resolving conflicts, `git merge --abort` |
| 7 | Rebasing | `git rebase`, interactive rebase (squash/reword/reorder), the golden rule of rebasing |
| 8 | Working with Remotes | `git remote`, `git clone`, `fetch` vs `pull`, `git push`, tracking branches |
| 9 | Stashing & Cleaning | `git stash`, `git clean` |
| 10 | Tags & Releases | Lightweight vs annotated tags, semantic versioning |
| 11 | Advanced Git | `cherry-pick`, `reflog`, `bisect`, submodules/worktrees/hooks (overview) |
| 12 | Config, Aliases & .gitignore | Config levels, useful aliases, deeper `.gitignore` patterns |

### GitHub track

| # | Chapter | Covers |
|---|---------|--------|
| 1 | Getting Started with GitHub | Accounts, SSH keys, creating/connecting a repo, repo anatomy |
| 2 | The GitHub Flow & Pull Requests | Branch → PR → review → merge, merge strategies, forking |
| 3 | Issues, Projects & Collaboration | Issues, labels, milestones, Projects boards, templates |
| 4 | GitHub Actions (CI/CD) | Workflow YAML, triggers, a real Python test workflow, secrets |
| 5 | GitHub Pages | Hosting a static site straight from a repo |
| 6 | Security & Best Practices | Branch protection, secret scanning, Dependabot, repo hygiene files |
| 7 | GitHub CLI & Beyond | The `gh` command, Gists, Wikis, a pointer to the API |

Start here: [`git/01-introduction-and-setup/README.md`](git/01-introduction-and-setup/README.md)
